<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-10"><h1 class="card-title">   </h1></div>
                </div>
                <hr>
                <div class="card-body">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>


                    <form action="<?php echo e(route('admin.product.store')); ?>" method="POST" accept-charset="UTF-8"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="header_ru">domen_name</label>
                            <input type="text" name="domen_name" class="form-control" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="header_ru">organization(tashkilot)</label>
                            <input type="text" name="organization" class="form-control" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="header_ru">phone</label>
                            <input type="tel" name="phone" pattern="{0,9}[9]" class="form-control"  placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="header_ru">from_date(domen yaratilgan vaqti)</label>
                            <input type="date" name="from_domen" class="form-control" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="header_ru">to_domen(tugash vaqti)</label>
                            <input type="date" name="to_domen" class="form-control"  placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="header_ru">	annotation(izoh)</label>
                            <input type="text" name="annotation" class="form-control" id="header_ru" placeholder="номи">
                        </div>






                        <button type="submit" id="alert" class="btn btn-primary">Submit</button>
                        <input type="reset" class="btn btn-danger" value="Очистить">
                    </form>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\saytlar\resources\views/admin/product/create.blade.php ENDPATH**/ ?>