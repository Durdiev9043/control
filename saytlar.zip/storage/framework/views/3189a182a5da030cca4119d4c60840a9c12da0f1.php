<?php $__env->startSection('content'); ?>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-9"><h1 class="card-title">  </h1></div>
                    <div class="col-md-1">
                        <a class="btn btn-primary" href="<?php echo e(route('admin.product.create')); ?>">
                            <span class="btn-label">
                                <i class="fa fa-plus"></i>
                            </span>
                            Qoshish
                        </a>
                    </div>
                </div>
                <hr>
                <div class="">
                    <table width="90%" class="table-bordered table-striped" id="mytable">
                        <thead>
                        <tr >
                            <th>Tashkilot nomi</th>
                            <th>Domen nomi &nbsp; </th>
                            <th>Shartnoma qilingan sana</th>
                            <th>Tugash sanasi</th>
                            <th>Telefon raqami</th>
                            <th>Dalolatnoma / sanasi</th>
                            <th>amallar</th>

                        </tr>

                        </thead>
                        <tbody>


                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="tr<?php echo e($product->id); ?>" <?php if( \Illuminate\Support\Carbon::now()->diffInDays( $product->to_domen) <= 30 ): ?> style="background: red;"<?php endif; ?> >


                                <td>
                                    <?php echo e($product->organization); ?>

                                </td>

                                <td>
                                    <?php echo e($product->domen_name); ?>

                                </td>

                                <td>
                                    <?php echo e(Carbon\Carbon::parse($product->from_domen)->format("d-M Y")); ?>-yil

                                </td>
                                <td>
                                    <?php echo e(Carbon\Carbon::parse($product->to_domen)->format("Y-M-d")); ?>


                                </td>
                                <td>
                                    <?php echo e($product->phone); ?>

                                </td>
                                <td>
                                    <?php echo e($product->annotation); ?>

                                </td>
                                <style>
                                    .dinayquy{
                                        opacity: 0;
                                    }
                                    .tr<?php echo e($product->id); ?>:hover .dinayquy{
                                        opacity: 1 !important;
                                    }
                                </style>
                                    <td>
                                        <form action="<?php echo e(route('admin.product.destroy',$product ->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="dinayquy">
                                            <div class=" btn-group" role="group">
                                            <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.product.edit',$product->id)); ?>">
                                    <span class="btn-label">
                                        <i class="fa fa-pen"></i>
                                    </span>
                                            </a>
                                            <button type="submit" class="btn btn-danger btn-sm"><span class="btn-label">
                                        <i class="fa fa-trash"></i>
                                    </span></button>
                                            </div>
                                            </div>
                                        </form>
                                    </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<script src="<?php echo e(asset('/assets/js/core/jquery.3.2.1.min.js')); ?>"></script>
<script>
    $(document).ready( function () {
    $('#mytable').DataTable({
        "language": {
            "lengthMenu": "_MENU_",
            "zeroRecords": " ",
            "info": "_PAGE_ / _PAGES_",
            "infoEmpty": " ",
            "search":"Qidirish:",
            "paginate": {
                "first": "биринчи",
                "previous": "олдинги",
                "next": "кейинки",
                "last": "охирги"
            },
        }});
} );
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\saytlar\resources\views/admin/product/index.blade.php ENDPATH**/ ?>